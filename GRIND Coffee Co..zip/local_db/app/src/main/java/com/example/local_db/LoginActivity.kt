package com.example.local_db

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.local_db.databinding.ActivityLoginBinding
import kotlinx.coroutines.launch

/**
 * LoginActivity handles user authentication.
 * It verifies credentials against the local Room database.
 */
class LoginActivity : AppCompatActivity() {

    // View binding for the login layout
    private lateinit var binding: ActivityLoginBinding
    // Local database instance
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Check if the user is already logged in using SharedPreferences.
        // NOTE: allowBackup is disabled in AndroidManifest.xml to ensure that 
        // uninstalled and reinstalled users are always forced to log in again.
        val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val isLoggedIn = sharedPref.getBoolean("isLoggedIn", false)

        if (isLoggedIn) {
            // If already logged in, skip the login screen and go to the dashboard
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
            return
        }

        // Set up the UI binding
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize the local Room database
        db = AppDatabase.getDatabase(this)

        // Handle the login button click
        binding.btnLogin.setOnClickListener {
            val rawIdentifier = binding.etEmail.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()

            // Validate that both fields are filled
            if (rawIdentifier.isNotEmpty() && password.isNotEmpty()) {
                // Execute database check in a coroutine
                lifecycleScope.launch {
                    // Try exact match first (for case-sensitive usernames)
                    var user = db.userDao().loginUser(rawIdentifier, password)
                    
                    // If not found, try lowercase (for emails or case-insensitive usernames)
                    if (user == null) {
                        user = db.userDao().loginUser(rawIdentifier.lowercase(), password)
                    }

                    if (user != null) {
                        // Success: Save login state in SharedPreferences
                        val editor = sharedPref.edit()
                        editor.putBoolean("isLoggedIn", true)
                        // Store the user's canonical email for consistency across the app
                        editor.putString("userEmail", user.email)
                        editor.apply()

                        // Navigate to the main dashboard
                        Toast.makeText(this@LoginActivity, "Login Successful", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@LoginActivity, MainActivity::class.java)
                        startActivity(intent)
                        finish()
                    } else {
                        // Failure: Show error message
                        Toast.makeText(this@LoginActivity, "Invalid Credentials", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                // Show warning if fields are empty
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
            }
        }

        // Navigate to the registration screen if the user doesn't have an account
        binding.tvGoToRegister.setOnClickListener {
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
    }
}