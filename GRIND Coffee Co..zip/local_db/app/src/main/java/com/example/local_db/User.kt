package com.example.local_db

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * User represents a customer account in the system.
 */
@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fullName: String,
    val username: String,
    val email: String,
    val password: String,
    val profileImageUri: String? = null,
    val rewardsPoints: Int = 0
)