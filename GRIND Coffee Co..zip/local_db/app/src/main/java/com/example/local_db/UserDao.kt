package com.example.local_db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

/**
 * UserDao defines the database operations for User entities.
 */
@Dao
interface UserDao {
    @Insert
    suspend fun registerUser(user: User)

    @Update
    suspend fun updateUser(user: User)

    @Query("SELECT * FROM users WHERE (email = :identifier OR username = :identifier) AND password = :password")
    suspend fun loginUser(identifier: String, password: String): User?

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmail(email: String): User?
}