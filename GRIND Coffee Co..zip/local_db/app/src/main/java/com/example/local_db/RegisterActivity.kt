package com.example.local_db

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.local_db.databinding.ActivityRegisterBinding
import kotlinx.coroutines.launch

/**
 * RegisterActivity allows new users to create an account.
 * Data is persisted in the local Room AppDatabase.
 */
class RegisterActivity : AppCompatActivity() {

    // View binding for the registration layout
    private lateinit var binding: ActivityRegisterBinding
    // Local database instance
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Set up the UI binding
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize the local database
        db = AppDatabase.getDatabase(this)

        // Handle the register button click
        binding.btnRegister.setOnClickListener {
            val username = binding.etUsername.text.toString().trim()
            val rawName = binding.etFullName.text.toString().trim()
            val fullName = if (rawName.isBlank()) "Customer" else rawName
            val email = binding.etEmail.text.toString().trim().lowercase()
            val password = binding.etPassword.text.toString().trim()
            val confirmPassword = binding.etConfirmPassword.text.toString().trim()

            // Validate that all registration fields are completed
            if (username.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty() && confirmPassword.isNotEmpty()) {
                
                if (username.length < 4) {
                    Toast.makeText(this, "Username must be at least 4 characters", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                if (password != confirmPassword) {
                    Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                if (!isPasswordSecure(password)) {
                    Toast.makeText(this, "Password must contain uppercase, lowercase, numbers, and special characters", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }

                // Create a new user object
                val user = User(fullName = fullName, username = username, email = email, password = password)
                // Save user to the database in a background coroutine
                lifecycleScope.launch {
                    // Ensure new accounts start with empty history
                    db.orderHistoryDao().clearHistoryByUser(email)

                    db.userDao().registerUser(user)
                    Toast.makeText(this@RegisterActivity, "Account created successfully", Toast.LENGTH_SHORT).show()
                    // After registration, redirect to the login page
                    val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            } else {
                // Alert user if any fields are missing
                Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show()
            }
        }

        // Navigate back to the login screen if the user already has an account
        binding.tvGoToLogin.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun isPasswordSecure(password: String): Boolean {
        // At least 1 uppercase, 1 lowercase, 1 digit, 1 special character, min 8 chars
        val passwordRegex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@\$!%*?&#])[A-Za-z\\d@\$!%*?&#]{8,}$"
        return password.matches(Regex(passwordRegex))
    }
}